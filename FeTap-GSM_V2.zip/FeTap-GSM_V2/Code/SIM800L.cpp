#include "Arduino.h"
#include "HardwareSerial.h"
#include"PinConfig.h"
#include "StateMachine.h"
#include "Buzzer.h"
#include "StateMachine.h"

// #define DEBUG_SIM800L

#ifndef DEBUG_SIM800L

#ifdef DEBUG_PRINTLN
#undef DEBUG_PRINTLN
#define DEBUG_PRINTLN(a)
#undef DEBUG_PRINT
#define DEBUG_PRINT(a)
#endif

#endif
void SendCmd(String cmd)
{
	DEBUG_PRINTLN(cmd);
	Serial2.println(cmd);
}

//#pragma region Freizeichen
bool FreizeichenOn = false;
int FreizeichenIrqCnt = 0;
void IRAM_ATTR ISR_Freizeichen()
{
	// Wählton bis 1979: 475 Hz, 200 – 300 – 700 – 800 ms
	// find this information on wikipedia https://de.wikipedia.org/wiki/H%C3%B6rton

	if (!FreizeichenOn)
		return;

	FreizeichenIrqCnt++;
	if (FreizeichenIrqCnt == 1)
	{
		SendCmd("AT+SIMTONE=1,475,200,100,300"); // SendCmd("AT+SIMTONE=1,475,200,300,500");
		return;
	}
	if (FreizeichenIrqCnt == 101)
	{
		SendCmd("AT+SIMTONE=1,475,700,100,800"); // SendCmd("AT+SIMTONE=1,475,700,800,1500");
		return;
	}
	if (FreizeichenIrqCnt == 500)
		FreizeichenIrqCnt = 0;
}

void StartFreizeichen()
{
	FreizeichenIrqCnt = 0;
	FreizeichenOn = true;
}

void CancelFreizeichen()
{
	if (!FreizeichenOn)
		return;
	FreizeichenOn = false;
	SendCmd("AT+SIMTONE=0");
}

//#pragma endregion

//#pragma region Besetztzeichen
bool BesetztzeichenOn = false;
int BesetztzeichenIrqCnt = 0;
void IRAM_ATTR ISR_Besetztzeichen()
{
	// Besetztton: 475 Hz, 125 – 475
	if (!BesetztzeichenOn)
		return;

	BesetztzeichenIrqCnt++;
	if (BesetztzeichenIrqCnt == 1)
	{
		SendCmd("AT+SIMTONE=1,475,200,100,200");
		return;
	}
	if (BesetztzeichenIrqCnt == 120)
		BesetztzeichenIrqCnt = 0;
}

void StartBesetztzeichen()
{
	BesetztzeichenIrqCnt = 0;
	BesetztzeichenOn = true;
}

void CancelBesetztzeichen()
{
	if (!BesetztzeichenOn)
		return;
	SendCmd("AT+SIMTONE=0");
	BesetztzeichenOn = false;
}
//#pragma endregion

void AcceptCall()
{
	delay(200); // be sure that all AT-commands are already finished and SIM800L is ready for next command
	SendCmd("ATA"); // Accepts incoming call. To reject, use directly "ATH"
}

void CancelCall()
{
	delay(200); // be sure that all AT-commands are already finished and SIM800L is ready for next command
	SendCmd("ATH"); //hang up
}

void ConnectToNumber(String dialstring)
{
	delay(200); // be sure that all AT-commands are already finished and SIM800L is ready for next command
	String connectCmd = "ATD" + dialstring + ";";
	SendCmd(connectCmd);
}

void IRAM_ATTR ISR_Ring()
{
	bool RingState = digitalRead(PIN_SIM_RING);
	if (RingState == LOW) // active low
		QueueEvent(ring_up);
	else
		QueueEvent(ring_down);
}

void DumpReceived()
{
#define OK_TIMEOUT 4000

	bool OKcame = false;
	static String rcvstr;
	int now = millis();

	while (!OKcame && ((millis() - now) < OK_TIMEOUT))
	{
		if (!Serial2.available())
			continue;

		uint8_t c = Serial2.read();
		if (isprint(c) || (c == '\r') || (c == '\n'))
		{
			if ((c != '\r') && (c != '\n'))
				rcvstr += (char)c;
			if (c == '\n')
			{
				if (rcvstr == "OK")
					OKcame = true;
				else
				{
					DEBUG_PRINTLN(rcvstr);
				}
				rcvstr = "";
			}
		}
		else
		{
			DEBUG_PRINTLN(c);
		}
	}
}

#ifdef DEBUG_SIM800L
void DebugQuestioning()
{
	DEBUG_PRINTLN("Is serial working? <OK>");
	SendCmd("AT");
	DumpReceived();

	DEBUG_PRINTLN("Module information <SIM800 R14.18>");
	SendCmd("ATI");
	DumpReceived();
	
	DEBUG_PRINTLN("Manufacturer information <SIMCOM_Ltd>");
	SendCmd("AT+CGMI");
	DumpReceived();
	
	DEBUG_PRINTLN("Module identification <SIMCOM_SIM800L>");
	SendCmd("AT+CGMM");
	DumpReceived();
	
	DEBUG_PRINTLN("Module identification <Revision:1418B04SIM800L24>");
	SendCmd("AT+CGMR");
	DumpReceived();

	DEBUG_PRINTLN("Akku state <+CBC: 0,75,4005> <LoadState,AkkuPercentage, Voltage>");
	SendCmd("AT+CBC");
	DumpReceived();

	DEBUG_PRINTLN("IMEI <864369036334641>");
	SendCmd("AT+CGSN");
	DumpReceived();

	DEBUG_PRINTLN("Is a pin necessary? <+CPIN: READY> means no PIN necessary");
	SendCmd("AT+CPIN?");
	delay(2000);
	DumpReceived();

	DEBUG_PRINTLN("Chip card interface device <898600810906F8048812>");
	SendCmd("AT+CCID");
	DumpReceived();

	DEBUG_PRINTLN("Signal strength <+CSQ: 20,0> <0..31 -> 0..-52dBm>");
	SendCmd("AT+CSQ");
	DumpReceived();

	DEBUG_PRINTLN("Connected to network <+COPS: 0,0,\"vodafone\">");
	SendCmd("AT+COPS?");
	DumpReceived();

	DEBUG_PRINTLN("Connected to network <+CREG: 0,1> <1=registered, 5=roaming>");
	SendCmd("AT+CREG?");
	DumpReceived();


	DEBUG_PRINTLN("Service provider <+CSPN: \"LIDL Connect\",0>");
	SendCmd("AT+CSPN?");
	DumpReceived();

	DEBUG_PRINTLN("Voice mail number <OK>");
	SendCmd("AT+CCVM?");
	DumpReceived();

	DEBUG_PRINTLN("GSM Location and Time <locationcode>[,<longitude>,<latitude>,<date>,<time>]");
	SendCmd("AT+CIPGSMLOC=1,1");
	DumpReceived();

	DEBUG_PRINTLN("Speaker volume");
	SendCmd("AT+CLVL?");
	DumpReceived();

	DEBUG_PRINTLN("Time of day <+CCLK: \"04 / 01 / 01, 00:22 : 10 + 32\">");
	SendCmd("AT+CCLK?");
	DumpReceived();
}
#endif

void Setup_SIM800L()
{
	pinMode(PIN_SIM_RING, INPUT_PULLUP);
	pinMode(PIN_SIM_DTR, OUTPUT);
	digitalWrite(PIN_SIM_DTR, LOW); // not in sleep mode
	pinMode(PIN_SIM_RST, OUTPUT);

	digitalWrite(PIN_SIM_RST, LOW); // Reset is active low
	delayMicroseconds(500);
	digitalWrite(PIN_SIM_RST, HIGH);
	Serial2.begin(38400, SERIAL_8N1, PIN_SIM_TXD, PIN_SIM_RXD);

	delay(5000);	// Module takes 4400 ms to boot.

	// Remove Waste of boot-reaction from serial buffer
	SendCmd("AT");
	DumpReceived(); // remove garbage coming at boot time
	SendCmd("ATE0"); // Disables local echo (not sending back the given command)
	DumpReceived();
	SendCmd("AT+SLEDS=2,40,60000"); // sets blinking in connected - mode to 60sec.
	DumpReceived();
	SendCmd("AT+CALM=1"); // Silent mode, no melody on incomming call
	DumpReceived();
	SendCmd("AT+CLIP=1"); // Enable +CLIP notification (nuber of a caller)
	DumpReceived();
	SendCmd("AT+MORING=1"); // Get a "MO RING" message if connection is ringing at remote, get "MO CONNECTED" if partner answers the call
	DumpReceived();

	bool GSMActive = false;
	for (int i = 0; i < 80; ++i)
	{
		SendCmd("AT+COPS?"); // Answer is either "+COPS: 0,0,"vodafone"" or "+COPS: 0", interrupted by the startup-messages "+CFUN: 1", "+CPIN: READY", "Call Ready", "SMS Ready"
		delay(500);

		String rcvbuf = "";
		while (Serial2.available())
			rcvbuf += (char)Serial2.read();

		if (rcvbuf.startsWith("\r\n+COPS: 0,")) // The comma notifies that more data is there in the string, so there is some connection to a network
		{
			GSMActive = true;
			BuzzerAsyncBeeps(2);
			break;
		}
	}
	if(!GSMActive)
		BuzzerAsyncBeeps(12);

	Serial2.flush();
#ifdef DEBUG_SIM800L
	DebugQuestioning();
#endif

	attachInterrupt(digitalPinToInterrupt(PIN_SIM_RING), ISR_Ring, CHANGE);
}


// identification commands
// SendACommand("AT"); Once the handshake test is successful, it will back to OK
		// OK

// SendACommand("ATI"); // Get module name and version
		// SIM800 R14.18 \OK

// AT+GMI / AT+CGMI Request manufacturer identification
		// SIMCOM_Ltd

// AT+GMM / AT+CGMM Request TA model identification
		// SIMCOM_SIM800L

// AT+GMR / AT+CGMR Request TA revision identification of software release
		// Revision:1418B04SIM800L24

// AT+GSV Display Product Identification Information
		// SIMCOM_Ltd
		// SIMCOM_SIM800L
		// Revision : 1418B04SIM800L24

// SendACommand("AT+CCID"); // SimInfo, Read SIM information to confirm whether the SIM is plugged
		// 89492024206007311325

// AT+GSN / AT+CGSN Get IMEI
	// 864369036334641

// AT+GOI Request global object identification
		// SIM800

// AT+CSPN? Get Service Provider Name from SIM
		// +CSPN: "",1

// AT+CCVM=? Get and Set the Voice Mail Number on the SIM
		// +CCVM: 40, 14

// AT+CIPGSMLOC=? GSM Location and Time
		// +CIPGSMLOC: (1,2),(1-3)

// AT+CSTA Select Type of Address (AT+CSTA? shows setting) 129=unknown, 161=national number, 145=international number, 177=network specific number
		// AT+CSTA? antwortet: +CSTA: 129
		// AT+CSTA=? antwortet: +CSTA: (129,145,161,177) which means Unknown type/National number type/International number type/Network specific number


// AT+CPOWD=0 Urgent Power off
		// reagiert anschließend nicht mehr. gleicher strom?

// AT&V shows current configuration
// DEFAULT PROFILE
		// S0: 0
		// S3 : 13
		// S4 : 10
		// S5 : 8
		// S6 : 2
		// S7 : 60
		// S8 : 2
		// S10 : 15
		// + CRLP : 61, 61, 48, 6
		// V : 1
		// E : 1			das ist die ECHO-setting
		// Q : 0
		// X : 4
		// & C : 1
		// & D : 1
		// + CLTS : 0
		// + CREG : 0
		// + CGREG : 0
		// + CMEE : 0
		// + CIURC : 1
		// + CFGRI : 2
		// + CMTE : 0
		// + CANT : 0, 0, 10
		// + STKPCIS : 0
		// + CMGF : 0
		// + CNMI : 2, 1, 0, 0, 0
		// + CSCS : "IRA"
		// + VTD : 1
		// + CALS : 1
		// + CHF : 0
		// + CAAS : 1
		// + CBUZZERRING : 0
		// + DDET : 0
		// + MORING : 0
		// + SVR : 16
		// + CCPD : 1
		// + CSNS : 0
		// + CSGS : 1
		// + CNETLIGHT : 1
		// + SLEDS : 64, 64, 64, 800, 3000, 300
		// + CSDT : 0
		// + CSMINS : 0
		// + EXUNSOL : 0
		// + FSHEX : 0
		// + FSEXT : 0
		// + IPR : 0
		// + IFC : 0, 0
		// + CSCLK : 0
		// 
		// USER PROFILE
		// der gleiche kram nochmal
		// 
		// ACTIVE PROFILE
		// der gleiche kram nochmal

// AT+GCAP Request complete TA capabilities list
		// +GCAP: +CGSM

// AT+IPR=<rate> sets baud rate
// AT+IPR?
		// +IPR: 9600
// AT+IPR=?
		// +IPR: (),(0,1200,2400,4800,9600,19200,38400,57600,115200,230400,460800)

// AT+SLEDS=2,40,60000 sets blinking in connected-mode to 60sec.

// AT+CPAS shows status 0=ready, 2=unknown, 3=ringing,4=call in progress
		// +CPAS: 0

// AT+CPOL? Preferred Operator List
	// +CPOL: 1,2,"40478"
	// +CPOL: 2, 2, "21401"
	// + CPOL : 3, 2, "22210"
	// + CPOL : 4, 2, "23415"
	// + CPOL : 5, 2, "22801"
	// + CPOL : 6, 2, "20404"
	// etc. bis 24

// AT+COPN=?  Operator Names
		// List of 630 operator names like:
		// +COPN: "20201","COSMOTE"
		// +COPN: "20205", "vodafone"
		// + COPN : "20209", "Q-TELECOM"
		// + COPN : "20210", "TIM"
		// + COPN : "20404", "vodafone"
		// + COPN : "20408", "KPN MOBILE"
		// etc. bis 630

// AT+CCLK?  Clock
		// +CCLK: "04/01/01,00:22:10+32"

// AT+CALM Alert Sound Mode 0 or 1 // AT+CALM=1   goes to silent mode
		// +CALM: 0

// AT+CALS Alert Sound Select
	// AT+CALS=1,1 plays sound 1 (of 1-19 sounds, no 17 is "Happy Birthday 2u")
	// AT+CALS=1,0 stops playing

// AT+CLVL Speaker Volume
		// has no effect if choosing volume 1-100

// AT+CMIC Change the Microphone Gain Level
		// Can't tell if it has effect

// A/ repeats last command given
// AT+CBC Battery state
	// +CBC: 0,81,4049 (=not charging/81%/4049mV)

// AT+CMTE? Set Critical Temperature Operating Mode or Query Temperature
		// +CMTE: 0,24.31   ->disabled temp. detection, 24.31 degrees celsius

// ATE0 echo mode off
// ATE1 echo mode on

// ATL<0-9> sets speaker loudness
		// no effect

// SendACommand("AT+CSQ";); 		// SignalQuality, value range is 0-31 , 31 is the best
		// +CSQ: 18, 0			means -80dB, no bit errors
		// AT+CSQ=? results: +CSQ: (0-31,99),(0-7,99)

// SendACommand("AT+CREG?"); 		// Check whether it has registered in the network
// // The second # should be 1 or 5. 1 indicates you are registered to home network and 5 indicates roaming network.Other than these two numbers indicate you are not registered to any network.
		// +CREG: 0,1		....unclear


// PIN handling
// AT+CPIN?   IsPinNecessary?
		// +CPIN: READY			means no pin required

// AT+CPIN=0000  Set pin to 0000

// beim login in netzwerk wird dann vom modul ausgegeben
// +CPIN: READY
// Call Ready
// SMS Ready

// AT+COPS=? List networks in range, takes some time!!
		// +COPS: (2,"vodafone","voda D2","26202"),(3,"D1","TMO D","26201"),,(0-4),(0-2)
// AT+COPS?  In which network?;
		// +COPS: 0, 0, "vodafone"

// SMS handling
// AT+CMGD=1 löscht die nachricht in speicherplatz 1
// AT+CMGF=1  Configure text mode for SMS. ('0' would be data mode)
// CmdSendSMS("01728112261", "Hallo hier bin ich.");
// SendACommand("AT+CNMI=1,2,0,0,0"); // Enable SMS receive());
// receive SMS
// SendACommand("AT+CNMI=1,2,0,0,0"); // Decides how newly arrived SMS messages should be handled
// Its response starts with +CMT: Response fields are comma-separated, first field being phone number. Second field is the name of person sending SMS. Third field is a timestamp, forth field is the message.
// AT+CPMS=? zeigt mögliche speicher für empfangene SMS
// AT+CPMS="SM" fragt nach, ob SMS auf der SIM-karte liegen. Antwort "+CPMS: 0,30,0,30,0,30" sagt, 0 von 30 möglichen speicherplätzen belegt
// +CMTI: "SM",1 ist eine MELDUNG des moduls, ohne vorheriges AT-kommando, und zeigt an, dass eine SMS in speicherplatz 1 empfangen wurde
// AT+CMGR=1 fragt die SMS in speicherplatz 1 ab
// listet alle vorhandenen nachrichten auf
// AT+CMGDA Delete All SMS

// AT+STTONE <mode>,<sound>,duration in ms up to 15300000 =255 minutes		Play SIM Toolkit Tone
		// mode 0 = stop playing, 1 = start playing
		// sounds 1-8 and 16-20, e.g. 1 = dialtone, 2 = busy

// AT+SIMTONE <mode>,<frequency>,<periodOn>,<periodOff>[,<duration>]		Generate Specifically Tone
		// SIMTONE: (0, 1), (20 - 20000), (200 - 25500), (0, 100 - 25500), (10 - 500000)
		// e.g. AT+SIMTONE=1,350,500,200,2000

// Wählton bis 1979: 475 Hz, 200 – 300 – 700 – 800 ms
// Freiton (klingeln): 1000 – 4000
// Besetztton: 125 – 475
// Dit: 1,475,200,300,500
// Dah: 1,475,700,800,1500

// make a call
// ATD+ +ZZxxxxxxxxxx;"); //  change ZZ with country code and xxxxxxxxxxx with phone number to dial
// ATD01728112261;	Calls that number
// ATD01728112261I; das gleiche mit rufnummernunterdrückung
// ATD reponses:
// BUSY
// NO CARRIER
// NO ANSWER
// OK

// SendACommand("ATH"); //hang up

// receive a call
// bei eingehendem call meldet das modem
// RING
// +CLIP:
// " 0177xxxxxxxxx" ,129,"" ,0,"" ,0

// SendACommand("ATA"); // Accepts incoming call. To reject, use directly "ATH"
		// OK
		// NO CARRIER, wenn anrufer auflegt

// ATH legt auf, modem meldet dann "NO CARRIER"



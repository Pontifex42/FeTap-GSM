#pragma once

// SIM800L
#define PIN_SIM_RING	32	// ~SIM_RING
#define PIN_SIM_DTR		2	// ~SIM_DTR
#define PIN_SIM_RXD		17	// RXD			
#define PIN_SIM_TXD		16	// TXD			
#define PIN_SIM_RST		4	// ~RST

// Buzzer
#define PIN_BUZZER		14	// BEEP

// microSD-Card reader
#define PIN_SPI_CS		5	// SPI_CS
#define PIN_SPI_SCK		18	// SPI_SCK
#define PIN_SPI_MISO	19	// SPI_MISO
#define PIN_SPI_MOSI	23	// SPI_MOSI

// Ancient phone
#define PIN_HOOK		35	// GABEL
#define HOOK_ONHOOK		1
#define HOOK_OFFHOOK	0

#define PIN_GROUNDKEY	36	// ERDE
#define GROUNDKEY_PRESSED 0
#define GROUNDKEY_RELEASED 1

#define PIN_DIALENABLE	12	// PIN_DIALENABLE
#define DIAL_ENABLED	0
#define DIAL_DISABLED	1

#define PIN_PULSE		39	// PIN_PULSE
#define DIAL_PULSEOFF	0
#define DIAL_PULSEON	1

// A4988 to drive ancient phones bell
#define PIN_ENAB		33	// ~ENAB
#define PIN_STEP		13	// STEP
#define PIN_BELL_POW	21	// BELL_EN

// Audio I2S audio modul MAX98357A
#define PIN_I2S_DOUT	25	// I2S_DOUT
#define PIN_I2S_LRC		26	// I2S_LRC
#define PIN_I2S_BCLK	27	// I2S_BCLK

// Relais to switch audio from I2S audio module or SIM800L audio output to phone speaker
#define PIN_RELAY		15	// AUDIOSW

// Battery guard measurement
#define PIN_VBAT		34	// VBAT

#define BELL_TIMER 1

#define DEBUG_PRINTLN(a) Serial.println(a)
//#define DEBUG_PRINTLN(a)
#define DEBUG_PRINT(a) Serial.print(a)
//#define DEBUG_PRINT(a)

#include "Arduino.h"
#include "PinConfig.h"
#include "SIM800L.h"

// #define DEBUG_BELL

#ifndef DEBUG_BELL

#ifdef DEBUG_PRINTLN
#undef DEBUG_PRINTLN
#define DEBUG_PRINTLN(a)
#undef DEBUG_PRINT
#define DEBUG_PRINT(a)
#endif

#endif


hw_timer_t* timerBell = NULL;

// Phone ring voltage is usually 25Hz
// We need a full LOW & HIGH cycle of step-signal for an inversion of bell coil voltage
// My A4988 module only acts on every second cycle, even if configured in full-step-mode
// so we need a blind high/low cycle, a step high/low cycle, another blind cycle and another step cycle for a full ring pulse
// so we have 2 + 2 + 2 + 2 = 8 digitalWrite within 40 ms (25Hz)
// correct timing should be 40ms/8 = 5ms = 5000us
// Note that timer is used for other timed singlalling, too, so do not modify the 5ms timing
#define BELL_TOGGLE_TIME 5000

inline void ToggleHammer()
{
	static bool pinState = LOW;
	digitalWrite(PIN_STEP, pinState);
	pinState = (pinState == LOW) ? HIGH : LOW;
}

inline void EnableBell()
{
	digitalWrite(PIN_ENAB, LOW); // active low
}

inline void DisableBell()
{
	digitalWrite(PIN_ENAB, HIGH); // active low
}

inline void EnableBellPower()
{
	digitalWrite(PIN_BELL_POW, HIGH); // active low
}

inline void DisableBellPower()
{
	digitalWrite(PIN_BELL_POW, LOW); // active low
}

bool RingBellOn = false;
int RingBellIrqCnt = 0;
void StartRingBell()
{
	DEBUG_PRINTLN("StartRingBell");
	EnableBellPower();
	RingBellIrqCnt = 0;
	RingBellOn = true;

	// sequence: 
	// phase 1 = ring for 500 ms
	// phase 2 = make a 300ms pause
	// phase 3 = ring again 500ms
	// phase 4 = wait for 2 seconds, than repeat
}

void CancelRingBell()
{
	DEBUG_PRINTLN("CancelRingBell");
	if (!RingBellOn)
		return;
	RingBellOn = false;
	DisableBell();
	DisableBellPower();
}

// To ring, follow a sequence as it is usually done by ancient phones: ring-ring,pause,ring-ring
void IRAM_ATTR ISR_OnTimerBell()
{
	ISR_Freizeichen();
	ISR_Besetztzeichen();

	if (!RingBellOn)
		return;

	RingBellIrqCnt++;
	if (RingBellIrqCnt == 1)
	{
		EnableBell();
	}
	else if (RingBellIrqCnt == 101)
	{
		DisableBell();
	}
	else if (RingBellIrqCnt == 161)
	{
		EnableBell();
	}
	else if (RingBellIrqCnt == 261)
	{
		DisableBell();
	}
	else if (RingBellIrqCnt == 661)
		RingBellIrqCnt = 0;

	ToggleHammer();
}

void Setup_Bell()
{
	digitalWrite(PIN_BELL_POW, LOW);
	pinMode(PIN_BELL_POW, OUTPUT);
	DisableBellPower();

	digitalWrite(PIN_ENAB, HIGH); // active low
	pinMode(PIN_ENAB, OUTPUT);
	DisableBell();

	digitalWrite(PIN_STEP, LOW);
	pinMode(PIN_STEP, OUTPUT);

	// We leave the timer interrupt running all the time, even if bell is off.
	// This is because of a bug in ESP32. The "yield"-fix found on git does not work
	timerBell = timerBegin(BELL_TIMER, 80, true);
	timerAttachInterrupt(timerBell, &ISR_OnTimerBell, true);
	timerAlarmWrite(timerBell, BELL_TOGGLE_TIME, true);

	// if the following yield() is removed, the timer will not
	// be enabled the second time, ref. to "ESP32 timerAlarmEnable() bug"
	// yield();
	timerAlarmEnable(timerBell);
}

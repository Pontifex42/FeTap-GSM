#pragma once

void Setup_Relay();
void RelayOn();
void RelayOff();

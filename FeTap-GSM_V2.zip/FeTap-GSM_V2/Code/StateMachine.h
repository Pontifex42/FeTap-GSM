#pragma once

typedef enum phonestate
{
	WAITING = 0,
	RINGING = 1,
	TALKING = 2,
	DISCONNECTED = 3,
	DIALING = 4,
	CONNECTING = 5,
}_state;


typedef enum stateevent
{
	ring_up = 0,
	ring_down = 1,
	offhook = 2,
	onhook = 3,
	quit = 4, // caller hooks on while talking or while ringing -> same as "ring end". Used for "No connection" at "Connecting", too.
	dial = 5,
	dialfinish = 6,
	connected = 7,
	noevent = 8,

}_event;

typedef void (*statefct)(void);
extern phonestate PhoneState;

void StateMachine();

void QueueEvent(stateevent newevent);
void CheckEventDialFinished();

String eventNoToText(stateevent e);
String stateNoToText(phonestate s);
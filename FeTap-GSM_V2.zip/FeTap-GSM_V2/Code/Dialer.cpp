#include "Arduino.h"
#include "PinConfig.h"
#include "StateMachine.h"
#include "SIM800L.h"

extern "C" {
#include "esp_timer.h"
}

// #define DEBUG_DIALER

#ifndef DEBUG_DIALER

#ifdef DEBUG_PRINTLN
#undef DEBUG_PRINTLN
#define DEBUG_PRINTLN(a)
#undef DEBUG_PRINT
#define DEBUG_PRINT(a)
#endif

#endif

#if defined DEBUG_DIALER
unsigned long lastIrqDialer = 0;
#endif

// *********** Dialed numbers queue *********** 
#define NUM_BUF_SIZE 20
volatile int DialedNumberQueue[NUM_BUF_SIZE];
volatile int DialedNumberIdx;
portMUX_TYPE muxNumberQueue = portMUX_INITIALIZER_UNLOCKED;

void PushDialedNumber(int iNum)
{
	portENTER_CRITICAL(&muxNumberQueue);
	if (DialedNumberIdx < NUM_BUF_SIZE)
	{
		DialedNumberQueue[DialedNumberIdx] = iNum;
		DialedNumberIdx++;
		QueueEvent(dial);
	}
	portEXIT_CRITICAL(&muxNumberQueue);
}

bool PopDialedNumber(int* num)
{
	bool ret = false;
	portENTER_CRITICAL(&muxNumberQueue);
	if (DialedNumberIdx)
	{
		(*num) = DialedNumberQueue[0];
		ret = true;
		DialedNumberIdx--;
		for (int i = 0; i < DialedNumberIdx; ++i)
			DialedNumberQueue[i] = DialedNumberQueue[i + 1];
	}
	portEXIT_CRITICAL(&muxNumberQueue);
	return ret;
}

// *********** Pulse counter *********** 
portMUX_TYPE muxPulseCnt = portMUX_INITIALIZER_UNLOCKED;
int iPulseCnt = 0;


// *********** DialEnable-contact interrupt handling *********** 

uint8_t dialEnabled = false;
#define DEBOUNCE_TIME_DIALENABLE 85000 // [us] At rapid dialing, sometimes a phantom pulse comes within 85ms
esp_timer_handle_t timerDialEnable;
bool dialIsEnabled = false;
/*
	----- How the debouncing works -----
	The contacts may bounce within a time of some microseconds and,
	on a less reliable hardware, up to more than a millisecond.
	It is impossible to poll for the end of bouncing for that long time,
	cause all processes are blocked for that long time.
	So every time a contct triggers an interrupt, we start a single-shot-timer
	with DEBOUNCE_TIME_xxx microseconds.
	If there comes some more interrupts before timer ends, due to bouncing,
	the timer is restarted.
	This way, it is safe that as the timer interrupt callback runs, the last
	DEBOUNCE_TIME_xxx microseconds there was no interrupt triggered.
*/

// Main use of DialEnabled-Conbtact is to determine if a nuber-dialing-process is finished.
// We could prevent pulse-contact to work while DialEnable-contact is inactive, but that is already done by the mechanics
// Note: after reboot, this is triggered immediately, but as there were no pulses so far, it has no effect.
void IRAM_ATTR ISR_OnDialEnable()
{
	esp_timer_stop(timerDialEnable);
	esp_timer_start_once(timerDialEnable, DEBOUNCE_TIME_DIALENABLE);

#if defined DEBUG_DIALER
	int pin = digitalRead(PIN_DIALENABLE);
	unsigned long now = micros();
	unsigned long diff = now - lastIrqDialer;
	lastIrqDialer = now;
	if (pin == DIAL_ENABLED)
		Serial.print(" " + String(diff) + "E+");
	else
		Serial.print(" " + String(diff) + "E-");
#endif
}

void OnTimerDialEnable(void* arg)
{
	int pin = digitalRead(PIN_DIALENABLE);
#if defined DEBUG_DIALER
	if (pin == DIAL_ENABLED)
		DEBUG_PRINTLN(" Et+");
	else
		DEBUG_PRINTLN(" Et-");
#endif

	if (pin == DIAL_ENABLED)
	{
		if(dialIsEnabled == false) // at switch state from disabled to enabled, deactivate dialtone
			CancelFreizeichen();

		dialIsEnabled = true;
		return;
	}

	dialIsEnabled = false;

	// dialing process of one cipher finished, use the counted pulses and push a number in queue.
	portENTER_CRITICAL(&muxPulseCnt);
		int iNum = iPulseCnt;
		iPulseCnt = 0;
	portEXIT_CRITICAL(&muxPulseCnt);

	if ((iNum < 1) || (iNum > 10))
		return;

	if (iNum == 10)
		iNum = 0;

	PushDialedNumber(iNum);
	DEBUG_PRINTLN(" Dial " + String(iNum));
}


// *********** Pulse-contact interrupt handling *********** 

#define DEBOUNCE_TIME_PULSE 6000 // [us]. Usualy, 100us would do, but at rapid dialing, the cow goes mad on some mechanics.
esp_timer_handle_t timerPulse;

void IRAM_ATTR ISR_OnPulse()
{
#if defined DEBUG_DIALER
	unsigned long now = micros();
	unsigned long diff = now - lastIrqDialer;
	lastIrqDialer = now;
	if(digitalRead(PIN_PULSE))
		DEBUG_PRINT(" " + String(diff) + "P+");
	else
		DEBUG_PRINT(" " + String(diff) + "P-");
#endif

	esp_timer_stop(timerPulse);

	if (!dialIsEnabled)
		return;

	if (digitalRead(PIN_PULSE) != DIAL_PULSEON)
		return;

	esp_timer_start_once(timerPulse, DEBOUNCE_TIME_PULSE);
}

void OnTimerPulse(void* arg)
{
	if (!dialIsEnabled)
		return;

	int pin = digitalRead(PIN_PULSE);
#if defined DEBUG_DIALER
	if (pin)
		DEBUG_PRINT(" Pt+");
	else
		DEBUG_PRINT(" Pt-");
#endif
	
	if (pin == DIAL_PULSEON)
	{
		portENTER_CRITICAL(&muxPulseCnt);
		iPulseCnt++;
		portEXIT_CRITICAL(&muxPulseCnt);
	}
}

// *********** Setup *********** 
void Setup_Dialer()
{
	DialedNumberIdx = 0;

	esp_timer_create_args_t timerConfigPulse;
	timerConfigPulse.arg = NULL;
	timerConfigPulse.callback = OnTimerPulse;
	timerConfigPulse.dispatch_method = ESP_TIMER_TASK;
	timerConfigPulse.name = "Pulse";

	if (esp_timer_create(&timerConfigPulse, &timerPulse) != ESP_OK)
	{
		DEBUG_PRINTLN("timerPulse create failed.");
	}

	esp_timer_create_args_t timerConfigDealEnable;
	timerConfigDealEnable.arg = NULL;
	timerConfigDealEnable.callback = OnTimerDialEnable;
	timerConfigDealEnable.dispatch_method = ESP_TIMER_TASK;
	timerConfigDealEnable.name = "DialEnable";

	if (esp_timer_create(&timerConfigDealEnable, &timerDialEnable) != ESP_OK)
	{
		DEBUG_PRINTLN("timerDialEnable create failed.");
	}

	pinMode(PIN_DIALENABLE, INPUT_PULLUP);
	pinMode(PIN_PULSE, INPUT_PULLUP);
	attachInterrupt(digitalPinToInterrupt(PIN_DIALENABLE), ISR_OnDialEnable, CHANGE); // rising edge signals that dial-proces of one cipher has finished
	attachInterrupt(digitalPinToInterrupt(PIN_PULSE), ISR_OnPulse, RISING); // Only considering rising edges does all the work. Note that on some mechanics a falling edge may occur after dialenable is already gone.
}

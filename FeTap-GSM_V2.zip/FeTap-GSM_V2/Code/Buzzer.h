#pragma once

void Setup_Buzzer();
void BuzzerOn();
void BuzzerOn(uint32_t ms);
void BuzzerOff();
void BuzzerAsyncBeeps(int beeps);
#pragma once

void Setup_Dialer();
bool PopDialedNumber(int* num);

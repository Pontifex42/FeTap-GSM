#include "Preferences.h"
#include "Phonebook.h"
#include "PinConfig.h"

// #define DEBUG_PHONEBOOK

#ifndef DEBUG_PHONEBOOK

#ifdef DEBUG_PRINTLN
#undef DEBUG_PRINTLN
#define DEBUG_PRINTLN(a)
#undef DEBUG_PRINT
#define DEBUG_PRINT(a)
#endif

#endif

#define ENTRY_LENGTH 40 // 40 ciphers will fit
uint8_t ShortKeys[ENTRY_LENGTH][10];
#define PHONEBOOK_NAME "book"

Preferences preferences;

void Setup_Phonebook()
{
}

bool SaveInPhoneBook(String number, uint8_t idx)
{
	DEBUG_PRINTLN("Save in phonebook: " + number);
	if (idx > 9)
		return false;

	if (number != ReadFromPhoneBook(idx))
	{
		preferences.begin(PHONEBOOK_NAME, false);
		char key[2] = { (char)(idx + '0'), (char)0 };
		preferences.putString(key, number);
		preferences.end();
	}
	return true;
}

String ReadFromPhoneBook(uint8_t idx)
{
	DEBUG_PRINTLN("Read from phonebook " + String(idx));
	String ret;
	if (idx > 9)
		return ret;

	char key[2] = { (char)(idx + '0'), (char)0 };
	preferences.begin(PHONEBOOK_NAME, true);
	ret = preferences.getString(key, "");
	preferences.end();

	return ret;
}
#include "Arduino.h"
#include "PinConfig.h"
#include "GroundKey.h"
#include "Buzzer.h"
#include "StateMachine.h"

// #define DEBUG_GROUNDKEY

#ifndef DEBUG_GROUNDKEY

#ifdef DEBUG_PRINTLN
#undef DEBUG_PRINTLN
#define DEBUG_PRINTLN(a)
#undef DEBUG_PRINT
#define DEBUG_PRINT(a)
#endif

#endif

#if defined DEBUG_GROUNDKEY
unsigned long lastIrqGroundkey = 0;
#endif

#define DEBOUNCE_GROUNDKEY 10000 // In tests with this key, I found a bouncing of less than 100 microseconds.
portMUX_TYPE muxGroundkey = portMUX_INITIALIZER_UNLOCKED;
esp_timer_handle_t timerGroundkey;

#define TIME_LONGPRESS 3000
static volatile bool GroundKeyState;
static volatile bool lastGroundKeyState;
static volatile unsigned long TimeGroundkeyPressed = 0;
GroundKeyEvent_T GroundKeyEvent = groundkeynoevent;

void IRAM_ATTR ISR_Groundkey()
{
#ifdef DEBUG_GROUNDKEY
	int pin = digitalRead(PIN_GROUNDKEY);
	unsigned long now = micros();
	unsigned long diff = now - lastIrqGroundkey;
	lastIrqGroundkey = now;
	if (pin)
		DEBUG_PRINT(String(diff) + "G+ ");
	else
		DEBUG_PRINT(String(diff) + "G- ");
#endif

	if (PhoneState != DIALING)
		return;

	esp_timer_stop(timerGroundkey);
	esp_timer_start_once(timerGroundkey, DEBOUNCE_GROUNDKEY);
}

void OnTimerGroundkey(void* arg)
{
	portENTER_CRITICAL(&muxGroundkey);
	{
		GroundKeyState = digitalRead(PIN_GROUNDKEY);  // level is HIGH on key pressed

#ifdef DEBUG_GROUNDKEY
		unsigned long now = micros();
		unsigned long diff = now - lastIrqGroundkey;
		lastIrqGroundkey = now;
		if (GroundKeyState == GROUNDKEY_PRESSED)
			DEBUG_PRINTLN(String(diff) + " Gt+");
		else
			DEBUG_PRINTLN(String(diff) + " Gt-");
#endif
		if (PhoneState != DIALING)
		{
			GroundKeyEvent = groundkeynoevent;
			portEXIT_CRITICAL(&muxGroundkey);
			return;
		}

		if (GroundKeyState == GROUNDKEY_PRESSED)
		{
			if (lastGroundKeyState == GROUNDKEY_RELEASED) // button just pressed
			{
				lastGroundKeyState = GroundKeyState;
				TimeGroundkeyPressed = millis();
				BuzzerAsyncBeeps(1);
			}
		}
		else
		{
			if (lastGroundKeyState == GROUNDKEY_PRESSED) // button just released
			{
				lastGroundKeyState = GroundKeyState;
				if ((millis() - TimeGroundkeyPressed) < TIME_LONGPRESS) // short pressed
				{
					GroundKeyEvent = groundkeyshortevent;
					DEBUG_PRINTLN("groundkeyshortevent");
				}
			}
		}
	}
	portEXIT_CRITICAL(&muxGroundkey);
}

void CheckEventGroundkey()
{
	if (PhoneState != DIALING)
	{
		portENTER_CRITICAL(&muxGroundkey);
			GroundKeyEvent = groundkeynoevent;
		portEXIT_CRITICAL(&muxGroundkey);
		return;
	}

	portENTER_CRITICAL(&muxGroundkey);
	{
		if ((GroundKeyState == GROUNDKEY_PRESSED) && (GroundKeyEvent != groundkeylongevent) && ((millis() - TimeGroundkeyPressed) > TIME_LONGPRESS))
		{
			GroundKeyEvent = groundkeylongevent;
			DEBUG_PRINTLN("groundkeylongevent"); 
			BuzzerAsyncBeeps(3);
		}
	}
	portEXIT_CRITICAL(&muxGroundkey);
}

void Setup_GroundKey()
{
	esp_timer_create_args_t timerConfigGroundkey;
	timerConfigGroundkey.arg = NULL;
	timerConfigGroundkey.callback = OnTimerGroundkey;
	timerConfigGroundkey.dispatch_method = ESP_TIMER_TASK;
	timerConfigGroundkey.name = "Groundkey";

	if (esp_timer_create(&timerConfigGroundkey, &timerGroundkey) != ESP_OK)
	{
		DEBUG_PRINTLN("timerGroundkey create failed.");
	}

	lastGroundKeyState =
	GroundKeyState = GROUNDKEY_RELEASED;
	GroundKeyEvent = groundkeynoevent;
	pinMode(PIN_GROUNDKEY, INPUT_PULLUP);
	attachInterrupt(digitalPinToInterrupt(PIN_GROUNDKEY), ISR_Groundkey, CHANGE);
}

#pragma once

extern bool SelfCallMode;

void InitSelfCall(int c);
void StartSelfCallTimer();
void CancelSelfCall();
void StartSelfCallAudio();
void Setup_SelfCall();